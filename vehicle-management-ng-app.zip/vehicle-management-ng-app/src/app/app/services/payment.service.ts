import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class PaymentService {
  private lastPayment: any = null;

  setPaymentDetails(payment: { paymentId?: number; bookingId: number; amount: number }) {
    this.lastPayment = payment;
    localStorage.setItem('lastPayment', JSON.stringify(payment)); // ✅ persist
  }

  getPaymentDetails() {
    if (this.lastPayment) return this.lastPayment;

    const saved = localStorage.getItem('lastPayment');
    if (saved) {
      this.lastPayment = JSON.parse(saved);
      return this.lastPayment;
    }
    return null;
  }

  clearPaymentDetails() {
    this.lastPayment = null;
    localStorage.removeItem('lastPayment');
  }
}
